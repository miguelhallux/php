<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Define o tipo de documento como HTML5 -->
    <meta charset="UTF-8"> <!-- Define a codificação de caracteres para UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Garante que a página seja responsiva em dispositivos móveis -->
    <link rel="stylesheet" href="style.css"> <!-- Link para o arquivo de estilos CSS -->
    <link rel="stylesheet" href="spinner.css"> <!-- Link para estilos de um carregador (spinner) -->
    <title>Sorteio de Grupos</title> <!-- Título da página que aparece na aba do navegador -->
    
    <style>
        /* Estilos internos para o layout da página */

        #excluirContainer {
            display: none; /* Inicialmente oculta este container */
            justify-content: flex-end; /* Alinha os botões à direita */
            align-items: center; /* Alinha os botões verticalmente */
            font-size: 12px; /* Tamanho da fonte */
            width: 100%; /* O container ocupa toda a largura disponível */
        }

        #perguntaExcluir {
            display: flex; /* Usa Flexbox para alinhar itens */
            justify-content: flex-end; /* Alinha os botões à direita */
            align-items: center; /* Alinha os botões verticalmente */
            margin-right: 10px; /* Margem à direita */
            padding-right: 10px; /* Espaço interno à direita */
            margin-top: 40px; /* Margem superior */
            margin-bottom: 10px; /* Margem inferior */
            font-size: 12px; /* Tamanho da fonte */
            width: 100%; /* O container ocupa toda a largura disponível */
        }

        /* Estilo para os botões dentro do container de perguntas */
        #perguntaExcluir button {
            margin-left: auto; /* Coloca uma margem automática à esquerda para empurrar o botão para a direita */
            width: 22%; /* Largura do botão */
        }

        /* Estilo para o container de botões "Sair" e "Repetir" */
        #botaoSairRepetir {
            display: flex; /* Usa Flexbox para alinhar itens */
            flex-direction: column; /* Organiza os botões um embaixo do outro */
            width: 100%; /* O container ocupa toda a largura disponível */
            margin-top: 20px; /* Margem superior */
        }

        /* Estilo para os botões */
        #botaoSairRepetir button {
            background-color: #4CAF50; /* Cor de fundo verde */
            color: white; /* Cor do texto branca */
            border: none; /* Remove bordas padrão */
            border-radius: 5px; /* Bordas arredondadas */
            padding: 10px; /* Espaçamento interno dos botões */
            font-size: 16px; /* Tamanho da fonte */
            cursor: pointer; /* Muda o cursor para indicar que é um botão clicável */
            transition: background-color 0.3s ease; /* Transição suave para mudança de cor */
            width: 48%; /* Cada botão ocupa quase metade da largura */
        }

        /* Estilo para o botão ao passar o mouse */
        #botaoSairRepetir button:hover {
            background-color: #388E3C; /* Verde mais escuro quando o mouse está sobre o botão */
        }

        /* Estilo para os botões de confirmação de exclusão */
        #perguntaExcluir button {
            background-color: #4CAF50; /* Cor de fundo verde */
            color: white; /* Cor do texto branca */
            border: none; /* Remove bordas padrão */
            border-radius: 5px; /* Bordas arredondadas */
            padding: 10px; /* Espaçamento interno dos botões */
            font-size: 16px; /* Tamanho da fonte */
            cursor: pointer; /* Muda o cursor para indicar que é um botão clicável */
            transition: background-color 0.3s ease; /* Transição suave */
        }

        /* Estilo para o botão de exclusão ao passar o mouse */
        #perguntaExcluir button:hover {
            background-color: #388E3C; /* Verde mais escuro quando o mouse está sobre o botão */
        }

        /* Estilo para os botões no container de exclusão */
        #excluirContainer button {
            margin-top: 10px; /* Margem superior */
            width: 100%; /* Faz o botão ocupar 100% da largura do container */
            padding: 10px; /* Aumenta o espaço interno do botão */
            font-size: 16px; /* Aumenta o tamanho da fonte */
            background-color: #4CAF50; /* Cor de fundo verde */
            color: white; /* Cor do texto branca */
            border: none; /* Remove bordas padrão */
            border-radius: 5px; /* Bordas arredondadas */
            cursor: pointer; /* Muda o cursor para indicar que é um botão clicável */
            transition: background-color 0.3s ease; /* Animação suave ao mudar a cor de fundo */
        }

        /* Estilo para o botão de exclusão ao passar o mouse */
        #excluirContainer button:hover {
            background-color: #45a049; /* Muda a cor de fundo ao passar o mouse por cima */
        }

        /* Estilo para o título do resultado */
        #resultado h3 {
            color: #006400; /* Verde escuro */
            font-weight: bold; /* Texto em negrito */
            font-size: 20px; /* Tamanho da fonte */
            margin-bottom: 10px; /* Espaçamento abaixo do título */
        }
        
    </style>
</head>
<body>
    <header>
        <script>
            // Função para mostrar a pergunta sobre exclusão
            function mostrarPerguntaExcluir() {
                const perguntaExcluir = document.getElementById('perguntaExcluir');
                perguntaExcluir.style.display = 'block'; // Exibe a pergunta
            }

            // Função para mostrar o container de exclusão
            function mostrarExcluirContainer() {
                const container = document.getElementById('excluirContainer');
                container.style.display = 'block'; // Exibe o container
                document.getElementById('perguntaExcluir').style.display = 'none'; // Esconde a pergunta
            }

            // Função para dividir os alunos em grupos
            function dividirAlunos() {
                const numPessoas = parseInt(document.getElementById('numPessoas').value); // Obtém o número de pessoas do input
                const alunosSelecionados = Array.from(document.getElementById('alunosExcluir').selectedOptions).map(option => option.value); // Coleta alunos selecionados para exclusão

                // Verifica se o número de pessoas é válido
                if (isNaN(numPessoas) || numPessoas <= 0) {
                    alert("Por favor, insira um número válido."); // Alerta se o número não é válido
                    return;
                }
               

                document.getElementById('gerando').style.display = 'block'; // Mostra "gerando..."
                document.getElementById('resultado').style.display = 'none'; // Esconde o resultado

                  // Esconde os inputs e a pergunta de exclusão
                  document.querySelector('label[for="numPessoas"]').style.display = 'none'; // Esconde o label
    document.getElementById('numPessoas').style.display = 'none';
    document.getElementById('perguntaExcluir').style.display = 'none';
    document.getElementById('excluirContainer').style.display = 'none'; // Esconde o container de exclusão


                // Simula o processo de geração de grupos
                setTimeout(function() {
                    const alunosDivididos = agruparAlunos(numPessoas, alunosSelecionados); // Agrupa os alunos
                    document.getElementById('gerando').style.display = 'none'; // Esconde "gerando..."
                    document.getElementById('resultado').innerHTML = alunosDivididos; // Exibe os grupos gerados
                    document.getElementById('resultado').style.display = 'block'; // Mostra os grupos
                    document.getElementById('botaoSairRepetir').style.display = 'block'; // Mostra botões "Repetir" e "Sair"
                }, 3000); // Aguarda 3 segundos
            }

            // Função para agrupar alunos
            function agruparAlunos(numPessoas, excluir) {
                let nomes = [
                    "ALEXANDRE DA SILVA", "ALEXANDRE NIKITIN", "AYLANA RODRIGUES", "CLARICE DA SILVA", "DAVID OPANASIUK", "FILIPE RAMALHO", 
                    "FILIPE DA CUNHA", "GONÇALO FREITAS", "GONÇALO SILVA", "GONÇALO DA CUNHA", "HUGO DA SILVA", "IVO BARBOSA", 
                    "JAZMIN FERREIRA", "JOÃO DE MAGALHÃES", "JOÃO SOUZA", "JOÃO SOUSA", "JOSÉ PIRES", "MARCO PEREIRA", 
                    "MARTIM BARBOSA", "SARA VITORINO", "TIAGO COELHO", "VALTER JOÃO"
                ];

                // Filtra os alunos que foram selecionados para excluir
                nomes = nomes.filter(nome => !excluir.includes(nome)); // Mantém apenas os alunos que não estão na lista de exclusão

                // Embaralha o array de nomes
                nomes.sort(() => 0.5 - Math.random()); // Embaralha a ordem dos alunos

                // Calcula o número total de grupos
                const numGrupos = Math.floor(nomes.length / numPessoas); // Número de grupos completos
                let alunosExtras = nomes.length % numPessoas; // Alunos que sobram e devem ser distribuídos

                const grupos = []; // Array para armazenar os grupos
                let indiceNome = 0; // Índice para rastrear a posição atual na lista de alunos

                // Distribui os alunos nos grupos completos
                for (let i = 0; i < numGrupos; i++) {
                    let tamanhoGrupo = numPessoas; // Define o tamanho do grupo

                    // Adiciona o grupo ao array
                    grupos.push(nomes.slice(indiceNome, indiceNome + tamanhoGrupo)); // Pega uma fatia da lista de alunos
                    indiceNome += tamanhoGrupo; // Avança o índice para o próximo grupo
                }

                // Adiciona os alunos extras aos grupos existentes
                let grupoIndex = 0; // Índice do grupo atual
                while (alunosExtras > 0) {
                    grupos[grupoIndex].push(nomes[indiceNome]); // Adiciona um aluno extra ao grupo atual
                    indiceNome++; // Avança para o próximo aluno
                    alunosExtras--; // Reduz a quantidade de alunos extras
                    grupoIndex = (grupoIndex + 1) % grupos.length; // Move para o próximo grupo
                }

                // Cria uma string HTML para exibir os grupos
                let resultadoHTML = "";
                grupos.forEach((grupo, index) => {
                    resultadoHTML += `<h3>Grupo ${index + 1}</h3><ul>`; // Título do grupo
                    grupo.forEach(aluno => {
                        resultadoHTML += `<li>${aluno}</li>`; // Adiciona cada aluno à lista
                    });
                    resultadoHTML += `</ul>`; // Fecha a lista
                });

                return resultadoHTML; // Retorna o HTML gerado
            }

            // Função para repetir o sorteio
            function repetirSorteio() {
                window.location.reload(); // Recarrega a página para reiniciar o sorteio
            }

            // Função para sair do sorteio
            function sair() {
                alert("Sorteio encerrado. A página será fechada."); // Alerta ao usuário
                window.close(); // Tenta fechar a página
            }
        </script>
    </header>

    <section>
        <h1>Sorteio de Grupos 12A</h1> <!-- Título da seção -->

        <label for="numPessoas">Digite o número de pessoas por grupo:</label> <!-- Label para o input -->
        <input type="number" id="numPessoas" placeholder="Ex: 6"> <!-- Input para o número de pessoas por grupo -->

        <div id="perguntaExcluir"> <!-- Container que pergunta sobre a exclusão de alunos -->
            <p>Deseja excluir algum aluno do sorteio?</p> <!-- Pergunta -->
            <button onclick="mostrarExcluirContainer()">Sim</button> <!-- Botão que mostra o container de exclusão -->
            <button onclick="dividirAlunos()">Não</button> <!-- Botão que inicia a divisão de alunos -->
        </div>

        <div id="excluirContainer"> <!-- Container para seleção de alunos a excluir -->
            <label for="alunosExcluir">Selecione os alunos a eliminar do sorteio:</label> <!-- Label para o select -->
            <select id="alunosExcluir" multiple size="8"> <!-- Select múltiplo para escolher alunos -->
                <option value="ALEXANDRE DA SILVA">ALEXANDRE DA SILVA</option>
                <option value="ALEXANDRE NIKITIN">ALEXANDRE NIKITIN</option>
                <option value="AYLANA RODRIGUES">AYLANA RODRIGUES</option>
                <option value="CLARICE DA SILVA">CLARICE DA SILVA</option>
                <option value="DAVID OPANASIUK">DAVID OPANASIUK</option>
                <option value="FILIPE RAMALHO">FILIPE RAMALHO</option>
                <option value="FILIPE DA CUNHA">FILIPE DA CUNHA</option>
                <option value="GONÇALO FREITAS">GONÇALO FREITAS</option>
                <option value="GONÇALO SILVA">GONÇALO SILVA</option>
                <option value="GONÇALO DA CUNHA">GONÇALO DA CUNHA</option>
                <option value="HUGO DA SILVA">HUGO DA SILVA</option>
                <option value="IVO BARBOSA">IVO BARBOSA</option>
                <option value="JAZMIN FERREIRA">JAZMIN FERREIRA</option>
                <option value="JOÃO DE MAGALHÃES">JOÃO DE MAGALHÃES</option>
                <option value="JOÃO SOUZA">JOÃO SOUZA</option>
                <option value="JOÃO SOUSA">JOÃO SOUSA</option>
                <option value="JOSÉ PIRES">JOSÉ PIRES</option>
                <option value="MARCO PEREIRA">MARCO PEREIRA</option>
                <option value="MARTIM BARBOSA">MARTIM BARBOSA</option>
                <option value="SARA VITORINO">SARA VITORINO</option>
                <option value="TIAGO COELHO">TIAGO COELHO</option>
                <option value="VALTER JOÃO">VALTER JOÃO</option>
            </select>

            <button onclick="dividirAlunos()">Confirmar Exclusões e Dividir Alunos</button> <!-- Botão para confirmar exclusões e dividir alunos -->
        </div>

        <div id="gerando" style="display: none;"> <!-- Container que mostra que os grupos estão sendo gerados -->
            <div class="spinner"></div> <!-- Animação de carregamento -->
            <p>A sortear Alunos... Aguarde...</p> <!-- Mensagem de espera -->
        </div>

        <div id="resultado" style="display: none;"></div> <!-- Container que exibirá o resultado -->

        <div id="botaoSairRepetir" style="display: none;"> <!-- Container para os botões de repetição e saída -->
            <button onclick="repetirSorteio()">Repetir Sorteio</button> <!-- Botão para repetir o sorteio -->
            <a href="https://www.digitalform.pt" ><button onclick="sair()">Sair</button></a> <!-- Botão para sair -->
        </div>
    </section>
</body>
</html>
